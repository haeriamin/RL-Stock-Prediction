import pandas as pd
from pyfolio import timeseries
# import plotly.express as px
# import torch

from finrl.agents.stablebaselines3.models import DRLAgent
from finrl.plot import (
    backtest_stats,
    # backtest_plot,
    get_daily_return,
    get_baseline,
    convert_daily_return_to_pyfolio_ts,
)

# from pypfopt.efficient_frontier import EfficientFrontier
# from pypfopt import risk_models
# from pypfopt import EfficientFrontier
# from pypfopt import risk_models
# from pypfopt import expected_returns
# from pypfopt import objective_functions

import data
import model
import s1_train

def main(load_data):
    trained_ppo = s1_train.main(load_data=load_data , load_model=False) 

    trade = data.main(mode='test', load=load_data)

    # Calculate properties
    stock_dimension = len(trade.tic.unique())
    state_space = stock_dimension
    print(f'Stock Dimension: {stock_dimension}, State Space: {state_space}')

    # Indicators
    tech_indicator_list = ['macd', 'rsi_30', 'cci_30', 'dx_30']
    feature_dimension = len(tech_indicator_list)
    print(f'Feature Dimension: {feature_dimension}')

    # Environment parameters
    env_kwargs = dict(
        hmax = 100,
        initial_amount = 10000,
        transaction_cost_pct = 0,
        state_space = state_space,
        stock_dim = stock_dimension,
        tech_indicator_list = tech_indicator_list,
        action_space = stock_dimension,
        reward_scaling = 1e-1,
    )

    # Create environment
    e_trade_gym = model.StockPortfolioEnv(
        df = trade,
        **env_kwargs
    )

    unique_tic = trade.tic.unique()
    unique_trade_date = trade.date.unique()
    baseline_df = get_baseline(
        ticker = '^DJI',
        start = '2020-07-01',
        end = '2021-09-01'
    )

    baseline_df_stats = backtest_stats(baseline_df, value_col_name='close')
    baseline_returns = get_daily_return(baseline_df, value_col_name='close')
    dji_cumpod = (baseline_returns + 1).cumprod() - 1
    print(dji_cumpod)

    df_daily_return_ppo, df_actions_ppo = DRLAgent.DRL_prediction(
        model = trained_ppo,
        environment = e_trade_gym,
    )
    ppo_cumpod = (df_daily_return_ppo.daily_return + 1).cumprod() - 1
    DRL_strat_ppo = convert_daily_return_to_pyfolio_ts(df_daily_return_ppo)

    perf_func = timeseries.perf_stats
    perf_stats_all_ppo = perf_func(
        returns = DRL_strat_ppo,
        factor_returns = DRL_strat_ppo,
        positions = None,
        transactions = None,
        turnover_denom = 'AGB',
    )

    def extract_weights(drl_actions_list):
        weight_df = {'date': [], 'weights': []}
        for i in range(len(drl_actions_list)):
            date = drl_actions_list.index[i]
            tic_list = list(drl_actions_list.columns)
            weights_list = (
                drl_actions_list.reset_index()[list(drl_actions_list.columns)]
                .iloc[i]
                .values
            )
            weight_dict = {'tic': [], 'weight': []}
            for j in range(len(tic_list)):
                weight_dict['tic'] += [tic_list[j]]
                weight_dict['weight'] += [weights_list[j]]

            weight_df['date'] += [date]
            weight_df['weights'] += [pd.DataFrame(weight_dict)]

        weights = pd.DataFrame(weight_df)
        return weights

    ppo_weights = extract_weights(df_actions_ppo)


if __name__ == '__main__':
    main(load_data=True)


# import numpy as np
# from sklearn.model_selection import train_test_split
# from sklearn import datasets
# from sklearn import svm
# from sklearn import linear_model
# from sklearn.linear_model import LinearRegression
# from sklearn.metrics import mean_squared_error
# from math import sqrt
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.svm import SVR
# from sklearn.model_selection import cross_val_score
# from sklearn.tree import DecisionTreeRegressor


# def prepare_data(trainData):
#     train_date = sorted(set(trainData.date.values))
#     X = []
#     for i in range(0, len(train_date) - 1):
#         d = train_date[i]
#         d_next = train_date[i + 1]
#         y = (
#             train.loc[train['date'] == d_next]
#             .return_list.iloc[0]
#             .loc[d_next]
#             .reset_index()
#         )
#         y.columns = ['tic', 'return']
#         x = train.loc[train['date'] == d][['tic', 'macd', 'rsi_30', 'cci_30', 'dx_30']]
#         train_piece = pd.merge(x, y, on='tic')
#         train_piece['date'] = [d] * len(train_piece)
#         X += [train_piece]
#     trainDataML = pd.concat(X)
#     X = trainDataML[tech_indicator_list].values
#     Y = trainDataML[['return']].values

#     return X, Y


# train_X, train_Y = prepare_data(train)
# rf_model = RandomForestRegressor(
#     max_depth=35, min_samples_split=10, random_state=0
# ).fit(train_X, train_Y.reshape(-1))
# dt_model = DecisionTreeRegressor(
#     random_state=0, max_depth=35, min_samples_split=10
# ).fit(train_X, train_Y.reshape(-1))
# svm_model = SVR(epsilon=0.14).fit(train_X, train_Y.reshape(-1))
# lr_model = LinearRegression().fit(train_X, train_Y)


# def output_predict(model, reference_model=False):
#     meta_coefficient = {'date': [], 'weights': []}

#     portfolio = pd.DataFrame(index=range(1), columns=unique_trade_date)
#     initial_capital = 1000000
#     portfolio.loc[0, unique_trade_date[0]] = initial_capital

#     for i in range(len(unique_trade_date) - 1):

#         current_date = unique_trade_date[i]
#         next_date = unique_trade_date[i + 1]
#         df_current = df[df.date == current_date].reset_index(drop=True)
#         tics = df_current['tic'].values
#         features = df_current[tech_indicator_list].values
#         df_next = df[df.date == next_date].reset_index(drop=True)
#         if not reference_model:
#             predicted_y = model.predict(features)
#             mu = predicted_y
#             Sigma = risk_models.sample_cov(df_current.return_list[0], returns_data=True)
#         else:
#             mu = df_next.return_list[0].loc[next_date].values
#             Sigma = risk_models.sample_cov(df_next.return_list[0], returns_data=True)
#         predicted_y_df = pd.DataFrame(
#             {
#                 'tic': tics.reshape(
#                     -1,
#                 ),
#                 'predicted_y': mu.reshape(
#                     -1,
#                 ),
#             }
#         )
#         min_weight, max_weight = 0, 1
#         ef = EfficientFrontier(mu, Sigma)
#         weights = ef.nonconvex_objective(
#             objective_functions.sharpe_ratio,
#             objective_args=(ef.expected_returns, ef.cov_matrix),
#             weights_sum_to_one=True,
#             constraints=[
#                 {
#                     'type': 'ineq',
#                     'fun': lambda w: w - min_weight,
#                 },  # greater than min_weight
#                 {
#                     'type': 'ineq',
#                     'fun': lambda w: max_weight - w,
#                 },  # less than max_weight
#             ],
#         )

#         weight_df = {'tic': [], 'weight': []}
#         meta_coefficient['date'] += [current_date]
#         # it = 0
#         for item in weights:
#             weight_df['tic'] += [item]
#             weight_df['weight'] += [weights[item]]

#         weight_df = pd.DataFrame(weight_df).merge(predicted_y_df, on=['tic'])
#         meta_coefficient['weights'] += [weight_df]
#         cap = portfolio.iloc[0, i]
#         # current cash invested for each stock
#         current_cash = [element * cap for element in list(weights.values())]
#         # current held shares
#         current_shares = list(np.array(current_cash) / np.array(df_current.close))
#         # next time period price
#         next_price = np.array(df_next.close)
#         portfolio.iloc[0, i + 1] = np.dot(current_shares, next_price)

#     portfolio = portfolio.T
#     portfolio.columns = ['account_value']
#     portfolio = portfolio.reset_index()
#     portfolio.columns = ['date', 'account_value']
#     stats = backtest_stats(portfolio, value_col_name='account_value')
#     portfolio_cumprod = (portfolio.account_value.pct_change() + 1).cumprod() - 1

#     return portfolio, stats, portfolio_cumprod, pd.DataFrame(meta_coefficient)


# lr_portfolio, lr_stats, lr_cumprod, lr_weights = output_predict(lr_model)
# dt_portfolio, dt_stats, dt_cumprod, dt_weights = output_predict(dt_model)
# svm_portfolio, svm_stats, svm_cumprod, svm_weights = output_predict(svm_model)
# rf_portfolio, rf_stats, rf_cumprod, rf_weights = output_predict(rf_model)
# (
#     reference_portfolio,
#     reference_stats,
#     reference_cumprod,
#     reference_weights,
# ) = output_predict(None, True)