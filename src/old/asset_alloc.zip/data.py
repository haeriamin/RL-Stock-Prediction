import os
import pandas as pd
from finrl import config, config_tickers
from finrl.meta.preprocessor.yahoodownloader import YahooDownloader
from finrl.meta.preprocessor.preprocessors import FeatureEngineer, data_split


def main(mode, load):
    if not load:
        df = YahooDownloader(
            start_date = '2008-01-01',
            end_date = '2022-06-02',
            ticker_list = config_tickers.DOW_30_TICKER,
        ).fetch_data()

        df.to_csv(
            os.path.join('./', config.DATA_SAVE_DIR, 'raw_dow30.csv'),
            index = False)
    else:
        df = pd.read_csv(
            os.path.join('./', config.DATA_SAVE_DIR, 'raw_dow30.csv'))
    
    fe = FeatureEngineer(
        use_technical_indicator = True,
        use_turbulence = False,
        user_defined_feature = False,
    )

    df = fe.preprocess_data(df)

    # add covariance matrix as states
    df = df.sort_values(['date', 'tic'], ignore_index=True)
    df.index = df.date.factorize()[0]

    cov_list = []
    return_list = []

    # look back is one year
    lookback = 252
    for i in range(lookback, len(df.index.unique())):
        data_lookback = df.loc[i - lookback : i, :]
        price_lookback = data_lookback.pivot_table(
            index='date', columns='tic', values='close'
        )
        return_lookback = price_lookback.pct_change().dropna()
        return_list.append(return_lookback)

        covs = return_lookback.cov().values
        cov_list.append(covs)

    df_cov = pd.DataFrame(
        {
            'date': df.date.unique()[lookback:],
            'cov_list': cov_list,
            'return_list': return_list,
        }
    )
    df = df.merge(df_cov, on='date')
    df = df.sort_values(['date', 'tic']).reset_index(drop=True)

    if mode == 'train':
        df = data_split(df, '2009-04-01', '2020-04-01')
    elif mode == 'test':
        df = data_split(df, '2020-04-01', '2021-04-01')

    return df
